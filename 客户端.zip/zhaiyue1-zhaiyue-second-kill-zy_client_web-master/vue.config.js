module.exports = {
    devServer: {
        port: 3090,
        open: true
    }
}