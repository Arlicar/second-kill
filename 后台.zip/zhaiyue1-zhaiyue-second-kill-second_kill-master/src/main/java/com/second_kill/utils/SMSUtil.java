package com.second_kill.utils;

import com.alibaba.fastjson.JSONObject;
import com.github.qcloudsms.SmsSingleSender;
import com.github.qcloudsms.SmsSingleSenderResult;
import com.second_kill.entity.SMS;
import com.second_kill.service.ex.SystemException;

import java.util.Map;

public class SMSUtil {
    public static String sendSMS(SMS sms) {

        /*
        修改 1109984 code
        登录 1109983 code min
        注册 1109982 code min
         */
        String phoneNumber = sms.getPhone();
        Integer min = sms.getMin();
        String reStr = ""; //定义返回值
        // 短信应用SDK AppID  1400开头
        int appid = 1400568748;
        // 短信应用SDK AppKey
        String appkey = "3fb9f1c81883b765213f46cdb41767cf";
        // 短信模板ID，需要在短信应用中申请
        int templateId = sms.getTemplateId();
        // 签名，使用的是签名内容，而不是签名ID
        String smsSign = "小黑IT技术分享站";
        //随机生成四位验证码的工具类
        String code = sms.getCode();
        try {
            //参数，一定要对应短信模板中的参数顺序和个数，
            String[] params = {code, String.valueOf(min)};
            //创建ssender对象
            SmsSingleSender ssender = new SmsSingleSender(appid, appkey);
            //发送
            SmsSingleSenderResult result = ssender.sendWithParam("86", phoneNumber, templateId, params, smsSign, "", "");
            System.out.println(result);
            if (result.result == 0) {
                reStr = "success";
            } else {
                reStr = "fail";
            }
            return reStr;
        }  // json解析错误
        // 网络IO错误
        catch (Exception e) {
            // HTTP响应码错误
            e.printStackTrace();
        }// 网络IO错误

        return reStr;
    }

    public static void checkSMS(SMS sms) {
        String code = sms.getCode();
        String o = JedisUtil.getJson(sms.getPhone());
        assert o != null;
        Map<String, Object> map = JSONObject.parseObject(o);
        String verifyCode = map.get("code").toString();
        long createTime = Long.parseLong(map.get("createTime").toString());
        if (!verifyCode.equals(code)) {
            throw new SystemException("验证码错误(Code Error.)");
        }
    }
}
