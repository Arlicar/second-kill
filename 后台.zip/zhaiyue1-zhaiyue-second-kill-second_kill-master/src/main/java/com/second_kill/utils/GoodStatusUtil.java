package com.second_kill.utils;


import com.second_kill.entity.DepositGood;
import com.second_kill.entity.LoansGood;

import java.util.Date;
import java.util.List;

public class GoodStatusUtil {
    static public int getStatus(Date startTime, Date endTime) {
        Long currentTime = System.currentTimeMillis();
        if (currentTime < startTime.getTime()) return 0;
        else if (currentTime > endTime.getTime()) return 2;
        else return 1;
    }
    static public List<LoansGood> updateStatusLoans(List<LoansGood> goodList){
        for (int i = 0; i < goodList.size(); i++) {
            LoansGood tmp = goodList.get(i);
            tmp.setStatus(getStatus(tmp.getStartTime(),tmp.getEndTime()));
            goodList.set(i,tmp);
        }
        return goodList;
    }
    static public List<DepositGood> updateStatusDeposit(List<DepositGood> goodList){
        for (int i = 0; i < goodList.size(); i++) {
            DepositGood tmp = goodList.get(i);
            tmp.setStatus(getStatus(tmp.getStartTime(),tmp.getEndTime()));
            goodList.set(i,tmp);
        }
        return goodList;
    }
}
