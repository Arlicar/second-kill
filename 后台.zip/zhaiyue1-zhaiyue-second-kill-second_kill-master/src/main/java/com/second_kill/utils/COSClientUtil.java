package com.second_kill.utils;

import com.qcloud.cos.COSClient;
import com.qcloud.cos.ClientConfig;
import com.qcloud.cos.auth.BasicCOSCredentials;
import com.qcloud.cos.auth.COSCredentials;
import com.qcloud.cos.http.HttpProtocol;
import com.qcloud.cos.region.Region;

public class COSClientUtil {
    public static COSClient getCOSClient() {
        COSCredentials cred = new BasicCOSCredentials("AKIDvf9MKivtc7ML4YnmVzDDxSiiTzGH2Xop", "nKceQxEG2astd7KHxMUMyJNBj03rQjnb");
        Region region = new Region("ap-nanjing");
        ClientConfig clientConfig = new ClientConfig(region);
        clientConfig.setHttpProtocol(HttpProtocol.https);
        return new COSClient(cred, clientConfig);
    }
}
