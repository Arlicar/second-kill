package com.second_kill.entity;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName(autoResultMap = true)
public class Client implements Serializable {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String name;
    private String idCard;
    private String salt;
    private String username;
    private String password;
    private String avatar;
    private String phone;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "YYYY-MM-DD HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    @TableField(typeHandler = JacksonTypeHandler.class)
    private JSONObject attribute;
    private Double balance;

    public Client(String name, String idCard, String username, String avatar, String phone) {
        this.name = name;
        this.idCard = idCard;
        this.username = username;
        this.avatar = avatar;
        this.phone = phone;
    }
}
