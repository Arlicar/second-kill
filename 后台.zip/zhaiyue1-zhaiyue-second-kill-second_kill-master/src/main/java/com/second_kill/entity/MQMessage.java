package com.second_kill.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MQMessage implements Serializable {
    private OrderInfo orderInfo;
    private String token;
    private String md5;
}
