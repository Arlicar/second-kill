package com.second_kill.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class payMessage implements Serializable {
    private OrderInfo realOrder;
    private OrderInfo order;
    private Double balance;
    private Double price;
}
