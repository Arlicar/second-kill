package com.second_kill.entity.dashboard;

import lombok.Data;

import java.util.List;

@Data
public class DashBoardUser {
    private Integer visitsDay;
    private Integer visitsMonth;
    private String visitsDayOnDay;
    private String visitsWeekOnWeek;
    private Integer newUserDay;
    private Integer newUserMonth;
    private String newUserDayOnDay;
    private String newUserWeekOnWeek;
    private List<VisitChart> visitChart;
}
