package com.second_kill.entity.dashboard;


import lombok.Data;

import java.util.List;

@Data
public class DashboardSale {
    private String amountDay;
    private String amountMonth;
    private String amountDayOnDay;
    private String amountWeekOnWeek;
    private Integer orderDay;
    private Integer orderMonth;
    private String orderDayOnDay;
    private String orderWeekOnWeek;
    private List<GoodRank> depositRank;
    private List<GoodRank> loansRank;
    private List<SaleChart> saleChart;
    private List<CustomerChart> customerChart;
}
