package com.second_kill.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单相关的请求通用requestBody
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderInfo implements Serializable {
    private Boolean isLoans;
    private Boolean paid;
    private Integer number;
    private Integer goodId;
    private Integer userId;
    private Integer orderId;
    private String password;
    private Double totalPrice;
    private String msg;
    private String name;
    private Integer status;
    private String queueId;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;

    public OrderInfo(Integer status, String msg) {
        this.status = status;
        this.msg = msg;
    }
    public OrderInfo(LoansOrder order){
        this.orderId=order.getId();
        this.goodId=order.getGoodId();
        this.userId=order.getUserId();
        this.number=order.getNumber();
        this.status=order.getStatus();
        this.name=order.getName();
        this.totalPrice=order.getTotalPrice();
        this.paid=true;
        this.isLoans=true;
    }
    public OrderInfo(DepositOrder order){
        this.orderId=order.getId();
        this.goodId=order.getGoodId();
        this.userId=order.getUserId();
        this.status=order.getStatus();
        this.number=order.getNumber();
        this.name=order.getName();
        this.totalPrice=order.getTotalPrice();
        this.paid=true;
        this.isLoans=false;
    }
}
