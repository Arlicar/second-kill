package com.second_kill.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@AllArgsConstructor
@TableName(value = "loans_favor", autoResultMap = true, excludeProperty = "isLoans")
public class LoansFavor extends FavorGood implements Serializable {
    public LoansFavor(Integer userId, Integer goodId, Date dateTime) {
        super(null, userId, goodId, 1, dateTime);
    }
}