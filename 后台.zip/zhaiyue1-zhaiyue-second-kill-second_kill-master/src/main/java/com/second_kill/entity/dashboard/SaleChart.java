package com.second_kill.entity.dashboard;

import lombok.Data;

@Data
public class SaleChart {
    private String date;
    private Double deposit;
    private Double loans;
}
