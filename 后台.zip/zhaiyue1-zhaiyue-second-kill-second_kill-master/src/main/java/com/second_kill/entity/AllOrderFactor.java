package com.second_kill.entity;


import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 用于获取所有订单列表的接口，传入的数据
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class AllOrderFactor extends PageSize {
    private Boolean type;
    private Integer orderId;
    private String goodName;
    //@JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "YYYY-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;
    // @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "YYYY-MM-dd HH:mm:ss", timezone = "GMT+8")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;
    private Boolean status;
}
