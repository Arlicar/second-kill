package com.second_kill.interceptor;

import com.google.common.util.concurrent.RateLimiter;
import com.second_kill.service.ex.SystemException;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.concurrent.TimeUnit;


public class RateInterceptorOne implements HandlerInterceptor {
    private final RateLimiter rateLimiter = RateLimiter.create(670);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //创建令牌桶实例
        if (!rateLimiter.tryAcquire(5, TimeUnit.SECONDS)) {
            throw new SystemException("请求超时");
        }
        return true;
    }
}
