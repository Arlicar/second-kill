package com.second_kill.controller;

import ch.qos.logback.core.status.StatusUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.*;
import com.second_kill.mapper.IDepositOrderMapper;
import com.second_kill.mapper.ILoansOrderMapper;
import com.second_kill.service.IDepositsGoodService;
import com.second_kill.service.ILoansGoodService;
import com.second_kill.service.IPreFilterService;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.GoodStatusUtil;
import com.second_kill.utils.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/admin/good/")
public class AdminGoodController extends BaseController {


    private final IDepositsGoodService depositsGoodService;
    private final ILoansGoodService loansGoodService;
    private final IPreFilterService preFilterService;
    private final IDepositOrderMapper depositOrderMapper;
    private final ILoansOrderMapper loansOrderMapper;


    @Autowired
    AdminGoodController(IDepositsGoodService iDepositsGoodService, ILoansGoodService iLoansGoodService,
                        IPreFilterService preFilterService, IDepositOrderMapper depositOrderMapper, ILoansOrderMapper loansOrderMapper) {
        this.depositsGoodService = iDepositsGoodService;
        this.loansGoodService = iLoansGoodService;
        this.preFilterService = preFilterService;
        this.depositOrderMapper = depositOrderMapper;
        this.loansOrderMapper = loansOrderMapper;
    }

    @PostMapping("/addDeposit")
    public ResponseBean addDeposit(@RequestBody DepositGood depositsGood) {
        if (depositsGood == null) {
            throw new SystemException("参数不能为空");
        }
        depositsGood.setRemainNumber(depositsGood.getTotalNumber());
        depositsGood.setStatus(0);
        depositsGood.setTotalRepeatTimes(depositsGood.getRepeatTimes());
        depositsGoodService.getBaseMapper().insert(depositsGood);
        if (depositsGood.getIsFilter() != 0) {
            preFilterService.updateFilterDeposit(depositsGood);
        }
        return new ResponseBean(200, "新增成功", null);
    }

    @PutMapping("/updateDeposit")
    public ResponseBean updateDeposit(@RequestBody DepositGood depositsGood) {
        depositsGood.setTotalRepeatTimes(depositsGood.getRepeatTimes());
        depositsGoodService.getBaseMapper().updateById(depositsGood);
        if (depositsGood.getIsFilter() != 0) {
            preFilterService.updateFilterDeposit(depositsGood);
        } else preFilterService.clearFilterLoans(depositsGood.getId());
        return new ResponseBean(200, "更新成功", null);
    }

    @DeleteMapping("/deleteDeposit")
    public ResponseBean deleteDeposit(Integer id) {
        depositsGoodService.getBaseMapper().deleteById(id);
        preFilterService.clearFilterDeposit(id);
        return new ResponseBean(200, "删除成功", null);
    }

    @GetMapping("/getDepositList")
    public ResponseBean getDepositList(GoodSearch goodSearch) {
        QueryWrapper<DepositGood> qw = new QueryWrapper<>();
        Page<DepositGood> pages = depositsGoodService.page(new Page<>(goodSearch.getPage(), goodSearch.getSize()));
        if (!StringUtil.isBlank(goodSearch.getName())) {
            qw.like("name", goodSearch.getName());
        }
        if (goodSearch.getStartTime() != null) {
            qw.ge("start_time", goodSearch.getStartTime());
        }
        if (goodSearch.getStatus() != null) {
            Date currentTime = new Date();
            switch (goodSearch.getStatus()){
                case 0:qw.gt("start_time", currentTime);break;
                case 2:qw.lt("end_time", currentTime);break;
                case 1:
                    qw.le("start_time", currentTime);
                    qw.ge("end_time"  , currentTime);
                    break;
            }
        }
        depositsGoodService.getBaseMapper().selectPage(pages, qw);
        Map<String, Object> data = new HashMap<>();
        data.put("count", pages.getTotal());
        data.put("depositList", GoodStatusUtil.updateStatusDeposit(pages.getRecords()));
        return new ResponseBean(200, "查询成功", data);
    }


    @PostMapping("/addLoan")
    public ResponseBean addLoan(@RequestBody LoansGood loansGood) {
        if (loansGood == null) {
            throw new SystemException("参数不能为空");
        }
        loansGood.setRemainNumber(loansGood.getTotalNumber());
        loansGood.setStatus(0);
        loansGood.setTotalRepeatTimes(loansGood.getRepeatTimes());
        loansGoodService.getBaseMapper().insert(loansGood);
        if (loansGood.getIsFilter() == 1) {
            preFilterService.updateFilterLoans(loansGood);
        }

        return new ResponseBean(200, "新增成功", null);
    }

    @PutMapping("/updateLoan")
    public ResponseBean updateLoan(@RequestBody LoansGood loansGood) {
        loansGood.setTotalRepeatTimes(loansGood.getRepeatTimes());
        loansGoodService.getBaseMapper().updateById(loansGood);
        if (loansGood.getIsFilter() == 1) {
            preFilterService.updateFilterLoans(loansGood);
        } else preFilterService.clearFilterLoans(loansGood.getId());
        return new ResponseBean(200, "更新成功", null);
    }

    @DeleteMapping("/deleteLoan")
    public ResponseBean deleteById(Integer id) {
        loansGoodService.getBaseMapper().deleteById(id);
        preFilterService.clearFilterLoans(id);
        return new ResponseBean(200, "删除成功", null);
    }

    @GetMapping("/getLoanList")
    public ResponseBean getLoanList(GoodSearch goodSearch) {
        QueryWrapper<LoansGood> qw = new QueryWrapper<>();
        if (!StringUtil.isBlank(goodSearch.getName())) {
            qw.like("name", goodSearch.getName());
        }
        if (goodSearch.getStartTime() != null) {
            qw.ge("start_time", goodSearch.getStartTime());
        }
        if (goodSearch.getStatus() != null) {
            Date currentTime = new Date();
            switch (goodSearch.getStatus()){
                case 0:qw.gt("start_time", currentTime);break;
                case 2:qw.lt("end_time", currentTime);break;
                case 1:
                    qw.le("start_time", currentTime);
                    qw.ge("end_time"  , currentTime);
                    break;
            }
        }
        Page<LoansGood> pages = loansGoodService.page(new Page<>(goodSearch.getPage(), goodSearch.getSize()),qw);
        loansGoodService.getBaseMapper().selectPage(pages, qw);
        Map<String, Object> data = new HashMap<>();
        data.put("count", pages.getTotal());
        data.put("loansList", GoodStatusUtil.updateStatusLoans(pages.getRecords()));
        return new ResponseBean(200, "查询成功", data);
    }

    /**
     * 获取存款订单列表
     *
     * @param orderFactor
     * @return
     */
    @GetMapping("/getDepositListById")
    public ResponseBean getDepositListById(OrderFactor orderFactor) {
        PagesBean pagesBean = depositsGoodService.getDepositListById(orderFactor);
        Map<String, Object> data = new HashMap<>();
        data.put("orderList", pagesBean.getList());
        data.put("count", pagesBean.getCount());
        return new ResponseBean(200, "查询成功", data);
    }

    /**
     * 获取贷款订单列表
     *
     * @param orderFactor
     * @return
     */
    @GetMapping("/getLoanListById")
    public ResponseBean getLoanListById(OrderFactor orderFactor) {
        PagesBean pagesBean = loansGoodService.getLoanListById(orderFactor);
        Map<String, Object> data = new HashMap<>();
        data.put("orderList", pagesBean.getList());
        data.put("count", pagesBean.getCount());
        return new ResponseBean(200, "查询成功", data);
    }

    /**
     * 获取所有订单列表
     *
     * @param orderFactor
     * @return
     */
    @GetMapping("/getOrderList")
    public ResponseBean getOrderList(AllOrderFactor orderFactor) {
        orderFactor.setPage(orderFactor.getPage() - 1);
        PagesBean pagesBean = new PagesBean();
        if (orderFactor.getType() == null) {
            //查询所有订单
            List<Object> list = new ArrayList<>();
            list.addAll((Collection<?>) depositsGoodService.getAllOrder(orderFactor).getList());
            list.addAll((Collection<?>) loansGoodService.getAllOrder(orderFactor).getList());
            pagesBean.setList(list);
            pagesBean.setCount(Long.valueOf(depositOrderMapper.getOrderNumber(orderFactor))+ Long.valueOf(loansOrderMapper.getOrderNumber(orderFactor)));
        } else if (!orderFactor.getType()) {
            //查询所有存款订单
            pagesBean = depositsGoodService.getAllOrder(orderFactor);
        } else if (orderFactor.getType()) {
            //查询所有贷款订单
            pagesBean = loansGoodService.getAllOrder(orderFactor);
        }
        Map<String, Object> data = new HashMap<>();
        data.put("orderList", pagesBean.getList());
        data.put("count", pagesBean.getCount());
        return new ResponseBean(200, "查询成功", data);
    }

    @GetMapping("/getDepositDetail")
    public ResponseBean getDepositDetail(Integer id) {
        DepositGood good = depositsGoodService.getBaseMapper().selectById(id);
        good.setStatus(GoodStatusUtil.getStatus(good.getStartTime(),good.getEndTime()));
        return new ResponseBean(200, "查询成功", good);
    }

    @GetMapping("/getLoanDetail")
    public ResponseBean getLoanDetail(Integer id) {
        LoansGood good = loansGoodService.getBaseMapper().selectById(id);
        good.setStatus(GoodStatusUtil.getStatus(good.getStartTime(),good.getEndTime()));
        return new ResponseBean(200, "查询成功", good);
    }
}
