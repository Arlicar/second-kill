package com.second_kill.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.Admin;
import com.second_kill.entity.ResponseBean;
import com.second_kill.service.IAdminService;
import com.second_kill.utils.JWTUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/user")
public class AdminUserController extends BaseController {
    @Autowired
    IAdminService adminService;

    /**
     * 添加管理员
     *
     * @param admin
     * @return
     */
    @PostMapping("/add")
    public ResponseBean addAdmin(@RequestBody Admin admin) throws Exception {
        adminService.addAdmin(admin);
        return new ResponseBean(200, "添加管理员成功", null);
    }

    /**
     * 管理员登录
     *
     * @param admin
     * @return
     */
    @PostMapping("/login")
    public ResponseBean login(@RequestBody Admin admin) throws Exception {
        System.out.println("pending");
        Admin realAdmin = adminService.login(admin.getUsername(), admin.getPassword());
        Map<String, String> map = new HashMap<>();//构造jwt的map
        map.put("userId", realAdmin.getId().toString());
        map.put("admin", "YES");
        map.put("time", String.valueOf(System.currentTimeMillis()));
        String token = JWTUtils.getToken(map);//生成token
        Map<String, String> data = new HashMap<>();
        data.put("token", token);
        return new ResponseBean(200, "登录成功", data);
    }

    /**
     * 删除管理员
     *
     * @param id
     * @return
     */
    @DeleteMapping("/delete")
    public ResponseBean deleteAdmin(Integer id) {
        adminService.deleteAdmin(id);
        return new ResponseBean(200, "删除管理员成功", null);
    }

    /**
     * 获得管理员信息
     *
     * @param token
     * @return
     */
    @GetMapping("/getInfo")
    public ResponseBean getInfo(@RequestHeader(value = "token") String token) {
        Admin admin = adminService.getInfo(JWTUtils.JWTGetAdminId(token));
        return new ResponseBean(200, "获取成功", admin);
    }


    /**
     * 获取管理员列表
     *
     * @param page     第几页
     * @param size     一页多少条数据
     * @param username
     * @param phone
     * @return
     */
    @GetMapping("/adminList")
    public ResponseBean getAdminList(Integer page, Integer size, @Nullable String username, @Nullable String phone) {
        Map<String, Object> data = new HashMap<>();
        QueryWrapper<Admin> queryWrapper = new QueryWrapper<>();
        queryWrapper.select("id","name","username","phone","avatar","create_time");
        long count;
        if (username == null && phone == null) {
            Page<Admin> adminPage = new Page<>(page, size);
            Page<Admin> pages =adminService.getBaseMapper().selectPage(adminPage, queryWrapper);
            List<Admin> records = pages.getRecords();
            count = adminPage.getTotal();
            data.put("count", count);
            data.put("userList", records);
            return new ResponseBean(200, "返回成功", data);
        } else {
            if (username != null) {
                queryWrapper.like("username", username);
            } else {
                queryWrapper.like("phone", phone);
            }
        }
        IPage<Admin> pages = new Page<>(page, size);
        pages = adminService.getBaseMapper().selectPage(pages, queryWrapper);
        List<Admin> records = pages.getRecords();
        count = records.size();
        data.put("count", count);
        data.put("userList", records);
        return new ResponseBean(200, "返回成功", data);
    }

    /**
     * 修改管理员
     *
     * @param admin
     * @return
     */
    @PutMapping("/updateInfo")
    public ResponseBean updateInfo(@RequestBody Admin admin) throws Exception {
        adminService.updateInfo(admin.getId(), admin.getUsername(), admin.getAvatar(), admin.getPassword(), admin.getName(), admin.getPhone());
        return new ResponseBean(200, "修改成功", null);
    }
}
