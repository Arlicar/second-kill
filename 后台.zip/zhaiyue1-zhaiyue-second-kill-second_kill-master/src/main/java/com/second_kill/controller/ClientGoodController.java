package com.second_kill.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.second_kill.config.RedisPrefix;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.*;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.second_kill.mapper.IDepositOrderMapper;
import com.second_kill.mapper.ILoansOrderMapper;
import com.second_kill.service.*;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.GoodStatusUtil;
import com.second_kill.utils.JWTUtils;
import com.second_kill.utils.baidu.TimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import redis.clients.jedis.Jedis;

import java.util.*;

import static com.second_kill.utils.JedisUtil.getJedis;

@RestController
@RequestMapping("/client/good")
public class ClientGoodController extends BaseController {

    private final IDepositFavorService depositFavorService;
    private final ILoansFavorService loansFavorService;
    private final IDepositsGoodService depositsGoodService;
    private final ILoansGoodService loansGoodService;
    private final IPreFilterService preFilterService;
    private final IDepositOrderMapper depositOrderMapper;
    private final ILoansOrderMapper loansOrderMapper;

    @Autowired
    ClientGoodController(
            IDepositsGoodService depositsGoodService, ILoansGoodService loansGoodService, IDepositFavorService depositFavorService, ILoansFavorService loansFavorService,
            IDepositsGoodService iDepositsGoodService,
            ILoansGoodService iLoansGoodService,
            IPreFilterService preFilterService, IDepositOrderMapper depositOrderMapper,
            ILoansOrderMapper loansOrderMapper) {
        this.depositFavorService = depositFavorService;
        this.loansFavorService = loansFavorService;
        this.depositsGoodService = iDepositsGoodService;
        this.loansGoodService = iLoansGoodService;
        this.preFilterService = preFilterService;
        this.depositOrderMapper = depositOrderMapper;
        this.loansOrderMapper = loansOrderMapper;
    }

    @PostMapping("/addFavor")
    public ResponseBean addFavor(@RequestHeader(value = "token") String token, @RequestBody FavorGood favorGood) {
        Integer userId = JWTUtils.JWTGetUserId(token);
        try {
            if (favorGood.getIsLoans() == 1) {//贷款
                QueryWrapper<LoansFavor> qw = new QueryWrapper<>();
                Map<String,Integer> map = new HashMap<>();
                map.put("good_id",favorGood.getGoodId());
                map.put("user_id",userId);
                qw.allEq(map);
                if(loansFavorService.getBaseMapper().selectOne(qw) == null){
                    loansFavorService.getBaseMapper().insert(
                            new LoansFavor(
                                    userId,
                                    favorGood.getGoodId(),
                                    TimeUtil.getDateTime()
                            )
                    );
                }
            } else {
                QueryWrapper<DepositFavor> qw = new QueryWrapper<>();
                Map<String,Integer> map = new HashMap<>();
                map.put("good_id",favorGood.getGoodId());
                map.put("user_id",userId);
                qw.allEq(map);
                if(depositFavorService.getBaseMapper().selectOne(qw) == null){
                    depositFavorService.getBaseMapper().insert(
                            new DepositFavor(
                                    userId,
                                    favorGood.getGoodId(),
                                    TimeUtil.getDateTime()
                            )
                    );
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new SystemException("内部错误");
        }
        return new ResponseBean(200, "添加成功", null);
    }

    @DeleteMapping("/delFavor")
    public ResponseBean delFavor(@RequestHeader(value = "token") String token, Integer goodId, Boolean isLoans) {
        Integer userId = JWTUtils.JWTGetUserId(token);
        if (isLoans) {
            QueryWrapper<LoansFavor> qw = new QueryWrapper<>();
            Map<String,Integer> map = new HashMap<>();
            map.put("good_id",goodId);
            map.put("user_id",userId);
            qw.allEq(map);
            loansFavorService.getBaseMapper().delete(qw);
        } else {
            QueryWrapper<DepositFavor> qw = new QueryWrapper<>();
            Map<String,Integer> map = new HashMap<>();
            map.put("good_id",goodId);
            map.put("user_id",userId);
            qw.allEq(map);
            depositFavorService.getBaseMapper().delete(qw);
        }
        return new ResponseBean(200, "删除成功", null);
    }

    @GetMapping("/showFavor")
    public ResponseBean getFavor(@RequestHeader(value = "token") String token, Boolean isLoans) {
        Integer userId = JWTUtils.JWTGetUserId(token);
        if (isLoans) {
            QueryWrapper<LoansFavor> qw = new QueryWrapper<>();
            qw.eq("user_id", userId);
            qw.select("good_id");

            List<LoansFavor> queryRes = loansFavorService.getBaseMapper().selectList(qw);
            List<Integer> queryIds = new ArrayList<>();
            queryRes.forEach(i -> {
                queryIds.add(i.getGoodId());
            });
            List<LoansGood> goodRes;
            if (queryIds.isEmpty()) {
                goodRes = new ArrayList<>();
            } else {
                goodRes = loansGoodService.getBaseMapper().selectBatchIds(queryIds);
                goodRes.forEach(i -> {
                    i.setIsLoans(1);
                });
            }

            return new ResponseBean(200, "查询成功", goodRes);
        } else {
            QueryWrapper<DepositFavor> qw = new QueryWrapper<>();
            qw.eq("user_id", userId);
            qw.select("good_id");
            List<DepositFavor> queryRes = depositFavorService.getBaseMapper().selectList(qw);

            List<Integer> queryIds = new ArrayList<>();
            queryRes.forEach((favItem) -> {
                queryIds.add(favItem.getGoodId());
            });
            List<DepositGood> goodRes;
            if (queryIds.isEmpty()) {
                goodRes = new ArrayList<>();
            } else {
                goodRes = depositsGoodService.getBaseMapper().selectBatchIds(queryIds);
                goodRes.forEach(i -> {
                    i.setIsLoans(0);
                });
            }
            return new ResponseBean(200, "查询成功", goodRes);
        }
    }

    @GetMapping("/search")
    public ResponseBean search(GoodSearch goodSearch) {
        PagesBean pagesBean;
        if (goodSearch.getIsLoans()) {
            pagesBean = loansGoodService.search(goodSearch);
        } else {
            pagesBean = depositsGoodService.search(goodSearch);
        }
        Map<String, Object> data = new HashMap<>();
        data.put("count", pagesBean.getCount());
        if(goodSearch.getIsLoans()){
            data.put("goodList", GoodStatusUtil.updateStatusLoans((List<LoansGood>) pagesBean.getList()));
        }else{
            data.put("goodList", GoodStatusUtil.updateStatusDeposit((List<DepositGood>) pagesBean.getList()));
        }

        return new ResponseBean(200, "查询成功", data);
    }

    @GetMapping("/getDetail")
    public ResponseBean getDetail(@RequestHeader(value = "token") String token, Integer isLoans, Integer goodId) {
        Integer userId = JWTUtils.JWTGetUserId(token);
        Map<String, Object> filterObj = preFilterService.getFilterState(isLoans == 1, goodId, userId);

        String filterStatus = (String) filterObj.get("state");
        List<Rule> reasonList;
        if (Objects.equals(filterStatus, "rejected")) {
            JSONArray filterFailList = (JSONArray) filterObj.get("reason");
            if (filterFailList == null) {
                reasonList = new ArrayList<>();
            } else {
                reasonList = filterFailList.toJavaList(Rule.class);
            }
        } else {
            reasonList = new ArrayList<>();
        }
        if (isLoans == 1) {
            QueryWrapper<LoansFavor> queryWrapper = new QueryWrapper<>();
            Map<String,Integer> map = new HashMap<>();
            map.put("user_id",userId);
            map.put("good_id",goodId);
            queryWrapper.allEq(map);
            LoansGood retGood = loansGoodService.getBaseMapper().selectById(goodId);
            if (retGood == null) {
                return new ResponseBean(404, "无法找到对应的商品", null);
            } else {
                if (loansFavorService.getBaseMapper().selectOne(queryWrapper) == null) {
                    retGood.setIsFavor(0);
                }else {
                    retGood.setIsFavor(1);
                }
                if (retGood.getIsFilter() == 1) {
                    retGood.setFilterStatus(filterStatus);
                    retGood.setFilterFailList(reasonList);
                } else {
                    retGood.setFilterStatus("passed");
                    retGood.setFilterFailList(reasonList);
                }
                retGood.setIsLoans(1);
                return new ResponseBean(200, "success", retGood);
            }
        } else {
            QueryWrapper<DepositFavor> queryWrapper = new QueryWrapper<>();
            Map<String,Integer> map = new HashMap<>();
            map.put("user_id",userId);
            map.put("good_id",goodId);
            queryWrapper.allEq(map);
            DepositGood retGood = depositsGoodService.getBaseMapper().selectById(goodId);
            if (retGood == null) {
                return new ResponseBean(404, "无法找到对应的商品", null);
            } else {
                if (depositFavorService.getBaseMapper().selectOne(queryWrapper) == null) {
                    retGood.setIsFavor(0);
                }else {
                    retGood.setIsFavor(1);
                }
                retGood.setIsLoans(0);
                if (retGood.getIsFilter() == 1) {
                    retGood.setFilterStatus(filterStatus);
                    retGood.setFilterFailList(reasonList);
                } else {
                    retGood.setFilterStatus("passed");
                    retGood.setFilterFailList(reasonList);
                }
                return new ResponseBean(200, "success", retGood);
            }
        }
    }

    @GetMapping("/orderList")
    public ResponseBean getOrderList(@RequestHeader(value = "token") String token, ClientOrder order) {
        order.setUserId(JWTUtils.JWTGetUserId(token));
        order.setPage(order.getPage() - 1);
        Jedis jedis = getJedis();
        if (jedis == null) throw new SystemException("内部错误");
        if (order.getIsLoans() == 0) {
            List<DepositOrder> list = depositOrderMapper.getClientOrder(order);
            Map<String, Object> data = new HashMap<>();
            Map<String, String> depositOrder = jedis.hgetAll(RedisPrefix.ORDER_DEPOSIT);
            depositOrder.forEach((k, v) -> {
                OrderInfo lo = JSON.parseObject(v, OrderInfo.class);
                if (Objects.equals(lo.getUserId(), order.getUserId())) {
                    list.add(0,
                            new DepositOrder(
                                    lo.getOrderId(),
                                    lo.getCreateTime(),
                                    lo.getUserId(),
                                    lo.getNumber(),
                                    lo.getName(),
                                    "",
                                    lo.getTotalPrice(),
                                    lo.getPaid() ? 1 : 0,
                                    lo.getGoodId()
                            )
                    );
                }
            });
            int count = list.size();
            data.put("count", count);
            data.put("orderList", list);
            return new ResponseBean(200, "查询成功", data);
        } else {
            List<LoansOrder> list = loansOrderMapper.getClientOrder(order);
            int count = list.size();
            Map<String, Object> data = new HashMap<>();
            Map<String, String> loansOrder = jedis.hgetAll(RedisPrefix.ORDER_LOANS);
            loansOrder.forEach((k, v) -> {
                OrderInfo lo = JSON.parseObject(v, OrderInfo.class);
                if (Objects.equals(lo.getUserId(), order.getUserId())) {
                    list.add(0,
                            new LoansOrder(
                                    lo.getOrderId(),
                                    lo.getCreateTime(),
                                    lo.getUserId(),
                                    "",
                                    lo.getTotalPrice(),
                                    lo.getNumber(),
                                    lo.getName(),
                                    lo.getPaid() ? 1 : 0,
                                    lo.getGoodId()
                            )
                    );
                }
            });
            data.put("count", count);
            data.put("orderList", list);
            return new ResponseBean(200, "查询成功", data);
        }
    }

}
