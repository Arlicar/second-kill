package com.second_kill.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.second_kill.controller.exhandler.BaseController;
import com.second_kill.entity.*;
import com.second_kill.service.IDepositsGoodService;
import com.second_kill.service.ILoansGoodService;
import com.second_kill.service.IRuleGroupService;
import com.second_kill.service.IRuleService;
import com.second_kill.utils.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/rule")
public class AdminRuleController extends BaseController {

    IRuleService ruleService;

    IRuleGroupService ruleGroupService;

    ILoansGoodService loansGoodService;

    IDepositsGoodService depositsGoodService;

    @Autowired
    AdminRuleController(IRuleService ruleService, IRuleGroupService ruleGroupService, ILoansGoodService loansGoodService
            , IDepositsGoodService depositsGoodService) {
        this.ruleService = ruleService;
        this.ruleGroupService = ruleGroupService;
        this.loansGoodService = loansGoodService;
        this.depositsGoodService = depositsGoodService;
    }


    /**
     * 添加规则
     *
     * @param rule
     * @return
     */
    @PostMapping("/addRule")
    public ResponseBean addRule(@RequestBody Rule rule) {
        System.out.println(rule.getValue());
        ruleService.addRule(rule);
        return new ResponseBean(200, "添加成功", null);
    }

    /**
     * 删除规则
     *
     * @param id
     * @return
     */
    @DeleteMapping("/deleteRule")
    public ResponseBean deleteRule(Integer id) {
        ruleService.deleteRule(id);
        return new ResponseBean(200, "删除成功", null);
    }

    /**
     * 获取规则列表
     *
     * @param page 第几页
     * @param size 一共几条
     * @param name 规则名称
     * @param type 规则类型
     * @return
     */
    @GetMapping("/getRuleList")
    public ResponseBean getRuleList(Integer page, Integer size, @Nullable String name, @Nullable Integer type) {
        QueryWrapper<Rule> qw = new QueryWrapper<>();
        Page<Rule> rulePage = new Page<>(page, size);
        if (!StringUtil.isBlank(name)) {
            qw.eq("name", name);
        }
        if (type != null) {
            qw.eq("type", type);
        }
        ruleService.getBaseMapper().selectPage(rulePage, qw);
        Map<String, Object> data = new HashMap<>();
        data.put("count", rulePage.getTotal());
        data.put("ruleList", rulePage.getRecords());
        return new ResponseBean(200, "查询成功", data);
    }

    /**
     * 修改规则
     *
     * @param rule
     * @return
     */
    @PutMapping("/modifyRule")
    public ResponseBean modifyRule(@RequestBody Rule rule) {
        ruleService.modifyRule(rule);
        return new ResponseBean(200, "修改成功", null);
    }

    /**
     * 修改规则组
     *
     * @param id
     * @return
     */
    @DeleteMapping("/deleteRuleGroup")
    public ResponseBean deleteRuleGroup(Integer id) {
        ruleGroupService.deleteRuleGroup(id);
        return new ResponseBean(200, "删除成功", null);
    }

    /**
     * 添加规则组合
     *
     * @param ruleGroup
     * @return
     */
    @PostMapping("/addRuleGroup")
    public ResponseBean addRuleGroup(@RequestBody RuleGroup ruleGroup) {
        ruleGroupService.getBaseMapper().insert(ruleGroup);
        return new ResponseBean(200, "添加成功", null);
    }

    /**
     * 获取规则组合列表
     *
     * @param page
     * @param size
     * @param name
     * @return
     */
    @GetMapping("/getRuleGroupList")
    public ResponseBean getRuleGroupList(Integer page, Integer size, @Nullable String name) {
        Map<String, Object> data = new HashMap<>();
        List<RuleGroup> records = new ArrayList<>();
        long count;
        QueryWrapper<RuleGroup> queryWrapper = new QueryWrapper<>();
        if (StringUtil.isBlank(name)) {
            Page<RuleGroup> RulePage = new Page<>(page, size);
            Page<RuleGroup> pages = ruleGroupService.page(RulePage);
            records = pages.getRecords();
            count = RulePage.getTotal();
        } else {
            queryWrapper.like("name", name);
            IPage<RuleGroup> pages = new Page<>(page, size);
            pages = ruleGroupService.getBaseMapper().selectPage(pages, queryWrapper);
            records = pages.getRecords();
            count = records.size();
        }
        List<Map<String, Object>> ruleGroupList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Map<String, Object> ruleGroup = new HashMap<>();
            ruleGroup.put("id", records.get(i).getId());
            ruleGroup.put("name", records.get(i).getName());
            ruleGroup.put("description", records.get(i).getDescription());
            List<Rule> ruleList = new ArrayList<>();
            int _size = records.get(i).getRuleList().size();
            for (int j = 0; j < _size; j++) {
                Rule rule = ruleService.getBaseMapper().selectById(records.get(i).getRuleList().get(j));
                if (rule != null)
                    ruleList.add(rule);
            }
            ruleGroup.put("ruleList", ruleList);
            ruleGroupList.add(ruleGroup);
        }
        data.put("count", count);
        data.put("ruleGroupList", ruleGroupList);
        return new ResponseBean(200, "查询成功", data);
    }

    /**
     * 更新规则组合
     *
     * @param ruleGroup
     * @return
     */
    @PutMapping("/updateRuleGroup")
    public ResponseBean updateRuleGroup(@RequestBody RuleGroup ruleGroup) {
        ruleGroupService.getBaseMapper().updateById(ruleGroup);
        return new ResponseBean(200, "更新成功", null);
    }

    /**
     * 获取存款初筛规则列表
     *
     * @param id
     * @return
     */
    @GetMapping("/depositRuleList")
    public ResponseBean depositRuleList(Integer id) {
        DepositGood depositGood = depositsGoodService.getBaseMapper().selectById(id);
        List<Integer> ruleList = depositGood.getRuleList();
        List<Rule> data = new ArrayList<>();
        for (Integer integer : ruleList) {
            Rule rule = ruleService.getBaseMapper().selectById(integer);
            data.add(rule);
        }
        return new ResponseBean(200, "获取成功", data);
    }

    /**
     * 获取贷款初筛规则列表
     *
     * @param id
     * @return
     */
    @GetMapping("/loanRuleList")
    public ResponseBean loanRuleList(Integer id) {
        LoansGood loansGood = loansGoodService.getBaseMapper().selectById(id);
        List<Integer> ruleList = loansGood.getRuleList();
        List<Rule> data = new ArrayList<>();
        for (Integer integer : ruleList) {
            Rule rule = ruleService.getBaseMapper().selectById(integer);
            data.add(rule);
        }
        return new ResponseBean(200, "获取成功", data);
    }
}
