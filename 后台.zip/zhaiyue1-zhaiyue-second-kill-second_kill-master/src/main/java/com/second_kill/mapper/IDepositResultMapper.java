package com.second_kill.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.DepositResult;

import java.util.List;

public interface IDepositResultMapper extends BaseMapper<DepositResult> {
    List<DepositResult> depositFilterResult(Integer id, Integer page, Integer size);
}
