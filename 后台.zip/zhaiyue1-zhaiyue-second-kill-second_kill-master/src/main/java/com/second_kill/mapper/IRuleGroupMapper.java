package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.RuleGroup;

public interface IRuleGroupMapper extends BaseMapper<RuleGroup> {
}
