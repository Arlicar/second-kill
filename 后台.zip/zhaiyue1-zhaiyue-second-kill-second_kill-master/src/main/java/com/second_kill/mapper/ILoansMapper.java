package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.LoansGood;

import java.util.List;

public interface ILoansMapper extends BaseMapper<LoansGood> {
    List<Integer> getIdList();

    void updateRemain(Integer id, Integer remain);
    void updateStatus(Integer id, Integer status);

}
