package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.Client;

import java.util.List;

public interface IClientMapper extends BaseMapper<Client> {
    void updateBalance(Integer id, Double balance);
    List<String> selectUsername();
    void updateName(Integer userId,String idCard,String name);

}
