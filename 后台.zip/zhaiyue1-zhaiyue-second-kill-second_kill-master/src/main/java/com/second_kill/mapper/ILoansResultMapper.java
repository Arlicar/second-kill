package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.LoansResult;

import java.util.List;

public interface ILoansResultMapper extends BaseMapper<LoansResult> {
    /**
     * 获取贷款初筛id
     *
     * @param id
     * @param page
     * @param size
     * @return
     */
    List<LoansResult> loansFilterResult(Integer id, Integer page, Integer size);
}
