package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.Rule;

public interface IRuleMapper extends BaseMapper<Rule> {
}
