package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.LoansFavor;

public interface ILoansFavorMapper extends BaseMapper<LoansFavor> {

}
