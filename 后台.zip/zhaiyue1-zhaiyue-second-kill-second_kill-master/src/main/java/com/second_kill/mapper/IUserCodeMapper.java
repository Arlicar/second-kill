package com.second_kill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.second_kill.entity.UserCode;

public interface IUserCodeMapper extends BaseMapper<UserCode> {
}
