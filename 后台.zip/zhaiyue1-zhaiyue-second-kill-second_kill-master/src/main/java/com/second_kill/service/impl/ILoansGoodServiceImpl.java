package com.second_kill.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.*;
import com.second_kill.mapper.ILoansMapper;
import com.second_kill.mapper.ILoansOrderMapper;
import com.second_kill.service.ILoansGoodService;
import com.second_kill.utils.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;


@Service
public class ILoansGoodServiceImpl extends ServiceImpl<ILoansMapper, LoansGood> implements ILoansGoodService {
    @Autowired
    ILoansOrderMapper loansOrderMapper;

    @Override
    public PagesBean search(GoodSearch goodSearch) {
        QueryWrapper<LoansGood> qw = new QueryWrapper<>();
        if (!StringUtil.isBlank(goodSearch.getName())) {
            qw.like("name", goodSearch.getName());
        }
        if (goodSearch.getMinPrice() != null) {
            qw.ge("min_price", goodSearch.getMinPrice());
        }
        if (goodSearch.getMaxPrice() != null) {
            qw.le("max_price", goodSearch.getMaxPrice());
        }
        if (goodSearch.getStartTime() != null) {
            qw.ge("start_time", goodSearch.getStartTime());
        }
        if (goodSearch.getEndTime() != null) {
            qw.ge("end_time", goodSearch.getEndTime());
        }
        if (goodSearch.getStatus() != null) {
            Date currentTime = new Date();
            switch (goodSearch.getStatus()) {
                case 0:
                    qw.gt("start_time", currentTime);
                    break;
                case 2:
                    qw.lt("end_time", currentTime);
                    break;
                case 1:
                    qw.le("start_time", currentTime);
                    qw.ge("end_time", currentTime);
                    break;
            }
        }
        qw.func(i -> {
            if (goodSearch.getSort() != null) {
                if (goodSearch.getSort()) {
                    i.orderByDesc("price");
                } else {
                    i.orderByAsc("price");
                }
            }
        });
        Page<LoansGood> pages = this.page(new Page<>(goodSearch.getPage(), goodSearch.getSize()), qw);
        this.getBaseMapper().selectPage(pages, qw);
        return new PagesBean(pages.getTotal(), pages.getRecords());
    }

    @Override
    public PagesBean getLoanListById(OrderFactor orderFactor) {
        orderFactor.setPage(orderFactor.getPage() - 1);
        List<LoansOrder> list = loansOrderMapper.getLoansOrder(orderFactor);
        Long count = (long) list.size();
        return new PagesBean(count, list);
    }

    @Override
    public PagesBean getAllOrder(AllOrderFactor orderFactor) {
        List<LoansOrder> list = loansOrderMapper.getAllOrder(orderFactor);
        System.out.println(list);
        Long count = Long.valueOf(loansOrderMapper.getOrderNumber(orderFactor));
        return new PagesBean(count, list);
    }
}
