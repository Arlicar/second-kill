package com.second_kill.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.second_kill.config.RedisPrefix;
import com.second_kill.entity.Client;
import com.second_kill.entity.DepositGood;
import com.second_kill.entity.LoansGood;
import com.second_kill.entity.Rule;
import com.second_kill.service.*;
import com.second_kill.utils.StringUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;

import java.util.*;

import static com.second_kill.utils.JedisUtil.getJedis;
@Service
@EnableAsync
public class IPreFilterServiceImpl implements IPreFilterService {
    private final IClientService clientService;
    private final IDepositsGoodService depositsGoodService;
    private final ILoansGoodService loansGoodService;
    private final IRuleService ruleService;
    private final IMailSendService mailSendService;
    @Autowired
    IPreFilterServiceImpl(
            IClientService clientService,
            IDepositsGoodService iDepositsGoodService,
            ILoansGoodService iLoansGoodService,
            IRuleService ruleService,
            IMailSendService mailSendService) {
        this.clientService = clientService;
        this.depositsGoodService = iDepositsGoodService;
        this.loansGoodService = iLoansGoodService;
        this.ruleService = ruleService;
        this.mailSendService = mailSendService;
    }

    @Data
    @AllArgsConstructor
    private static class PreFilterQueueBean {
        private List<Client> users;
        private Integer goodId;
        private Boolean isLoans;
    }

    Thread inRunThread = null;
    Boolean isRunning = false;
    List<PreFilterQueueBean> preFilterQueue = Collections.synchronizedList(new ArrayList<>());


    @Override
    @Async("filterExecutor")
    public void updateFilterLoans(LoansGood good, List<Client> users) {
        if (good.getIsFilter() == 0)
            return;
        else if (good.getStartTime().getTime() > System.currentTimeMillis() + 600000)
            return;
        else if (good.getEndTime().getTime() <= System.currentTimeMillis())
            return;
        else updateFilter(true, good.getId(), users);
    }

    @Override
    @Async("filterExecutor")
    public void updateFilterDeposit(DepositGood good, List<Client> users) {
        if (good.getIsFilter() == 0)
            return;
        else if (good.getStartTime().getTime() > System.currentTimeMillis() + 600000)
            return;
        else if (good.getEndTime().getTime() <= System.currentTimeMillis())
            return;
        else updateFilter(false, good.getId(), users);
    }

    @Override
    @Async("filterExecutor")
    public void updateFilterLoans(LoansGood good, Client user) {
        ArrayList<Client> tmp = new ArrayList<>();
        tmp.add(user);
        updateFilterLoans(good, tmp);
    }

    @Override
    @Async("filterExecutor")
    public void updateFilterDeposit(DepositGood good, Client user) {
        ArrayList<Client> tmp = new ArrayList<>();
        tmp.add(user);
        updateFilterDeposit(good, tmp);
    }

    @Override
    @Async("filterExecutor")
    public void updateFilterLoans(LoansGood good) {
        QueryWrapper<Client> qw = new QueryWrapper<>();
        qw.select("id","attribute","username");
        qw.ne("id",0);
        updateFilterLoans(good,clientService.getBaseMapper().selectList(qw));
    }

    @Override
    @Async("filterExecutor")
    public void updateFilterDeposit(DepositGood good) {
        QueryWrapper<Client> qw = new QueryWrapper<>();
        qw.select("id","attribute","username");
        qw.ne("id",0);
        updateFilterDeposit(good,clientService.getBaseMapper().selectList(qw));
    }

    /**
     * 更新所有初筛信息，当用户信息被导入时触发
     */
    @Override
    @Async("filterExecutor")
    public void updateAllFilter() {
        QueryWrapper<Client> qw = new QueryWrapper<>();
        qw.select("id","attribute","username");
        qw.ne("id",0);
        List<Client> clients =  clientService.getBaseMapper().selectList(qw);
        loansGoodService.getBaseMapper().selectList(new QueryWrapper<>()).forEach((good) -> updateFilterLoans(good,clients));
        depositsGoodService.getBaseMapper().selectList(new QueryWrapper<>()).forEach((good) -> updateFilterDeposit(good,clients));
    }
    @Override
    @Async("filterExecutor")
    public void updateAllFilter(Client user) {
        loansGoodService.getBaseMapper().selectList(new QueryWrapper<>()).forEach((good) -> updateFilterLoans(good,user));
        depositsGoodService.getBaseMapper().selectList(new QueryWrapper<>()).forEach((good) -> updateFilterDeposit(good,user));
    }

    /**
     * 方法用于创建/要求更新预初筛数据。
     *
     * @param isLoans
     * @param goodId
     * @param users
     */
    private void updateFilter(Boolean isLoans, Integer goodId, List<Client> users) {
        for (PreFilterQueueBean e : preFilterQueue) {
            if (Objects.equals(e.getGoodId(), goodId) && e.getIsLoans() == isLoans) {
                List<Client> queuedUsr = e.getUsers();
                users.forEach((usr) -> {
                    for (Client susr : queuedUsr) {
                        if (susr.equals(usr)) {
                            return;
                        }
                    }
                    queuedUsr.add(usr);
                });
                controlThread(true);
                return;
            }
        }
        preFilterQueue.add(new PreFilterQueueBean(users, goodId, isLoans));
        controlThread(true);
    }

    /**
     * 初筛主线程函数。用于更新初筛数据。
     */
    @Async("filterExecutor")
    public void preFilterWorkLoop() {
        inRunThread = Thread.currentThread();

        while (!preFilterQueue.isEmpty()) {
            try {
                PreFilterQueueBean tmp = preFilterQueue.get(0);
                preFilterQueue.remove(0);
                if (tmp.getIsLoans()) {
                    LoansGood good = loansGoodService.getBaseMapper().selectById(tmp.goodId);
                    updateGoodFilterLoansWork(good, tmp.users);
                } else {
                    DepositGood good = depositsGoodService.getBaseMapper().selectById(tmp.goodId);
                    updateGoodFilterDepositWork(good, tmp.users);
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }

        inRunThread = null;
        controlThread(false);
    }

    private void updateGoodFilterLoansWork(LoansGood good, List<Client> clients) {
        String goodId = good.getId().toString();
        System.out.println("LOANS_" + goodId + "初筛开始:"+ clients.size());

        StringBuilder errorText = new StringBuilder();
        Boolean hasError = false;

        if (good.getIsFilter() == null || good.getIsFilter() != 1) return;
        Jedis jedis = getJedis();
        assert jedis != null;
        jedis.set(RedisPrefix.FILTER_LOANS_STATUS + goodId, "running");
        jedis.del(RedisPrefix.FILTER_LOANS_RESULT + goodId);
        jedis.del(RedisPrefix.FILTER_LOANS_REASON + goodId);
        List<Integer> filters = good.getRuleList();
        List<Rule> rules;

        if(filters==null || filters.size()==0) {
            errorText.append("<p>商品 <b>")
                    .append(good.getName())
                    .append("#")
                    .append(goodId)
                    .append("</b> 未指定任何初筛规则</p>");
            hasError = true;
            rules = new ArrayList<>();
        }else rules = ruleService.getBaseMapper().selectBatchIds(filters);

        Map<String, String> resultMap = new HashMap<>();
        Map<String, String> reasonMap = new HashMap<>();

        for (Client client : clients) {
            List<Rule> failedRules = new ArrayList<>();
            JSONObject clientInfo = client.getAttribute();
            if (clientInfo == null) {
                hasError = true;
                errorText
                    .append("<p>用户 <b>")
                    .append(client.getUsername())
                    .append("#")
                    .append(client.getId())
                    .append("</b> 信息不存在</p>");
                continue;
            }
            boolean clientRes = true;
            for (Rule rule : rules) {
                switch (judgeRule(clientInfo, rule)) {
                    case -1:
                        clientRes = false;
                        failedRules.add(rule);
                        break;
                    case -2:
                        errorText
                            .append("<p>规则配置错误:<b>")
                            .append(rule.getName())
                            .append("</b> 未指定驱动变量名</p>");
                        hasError=true;
                        break;
                    case -3:
                        errorText
                                .append("<p>规则配置 <b>")
                                .append(rule.getName())
                                .append("</b> 的驱动变量 <b>")
                                .append(rule.getVariable())
                                .append("</b> 在用户 <b>")
                                .append(client.getUsername())
                                .append("#")
                                .append(client.getId())
                                .append("中不存在</b></p>");
                        hasError=true;
                        break;
                }
            }
            if (clientRes) {
                resultMap.put(String.valueOf(client.getId()), "pass");
                reasonMap.put(String.valueOf(client.getId()), "[]");
                //System.out.println(client.getUsername() + "#" + client.getId().toString() + " 审查【通过】");
            } else {
                resultMap.put(String.valueOf(client.getId()), "reject");
                reasonMap.put(String.valueOf(client.getId()), JSONObject.toJSONString(failedRules));
                //.out.println(client.getUsername() + "#" + client.getId().toString() + " 审查【拒绝】:" + failedRules);
            }
        }
        jedis.hset(RedisPrefix.FILTER_LOANS_RESULT + goodId, resultMap);
        jedis.hset(RedisPrefix.FILTER_LOANS_REASON + goodId, reasonMap);
        jedis.set(RedisPrefix.FILTER_LOANS_STATUS + goodId, "finished");
        jedis.close();
        System.out.println("LOANS_" + goodId + "初筛已完成");
        if(hasError){
            mailSendService.sendToAdmin("商品 "+good.getName() +" 初筛时发生了错误！","错误报告",errorText.toString());
        }
    }
    private void updateGoodFilterDepositWork(DepositGood good, List<Client> clients) {
        String goodId = good.getId().toString();
        System.out.println("DEPOSIT_" + goodId + "初筛开始:"+ clients.size());
        Jedis jedis = getJedis();
        assert jedis != null;

        StringBuilder errorText = new StringBuilder();
        Boolean hasError = false;

        List<Integer> filters = good.getRuleList();
        List<Rule> rules;
        if(filters==null || filters.size()==0) {
            errorText.append("<p>商品 <b>")
                    .append(good.getName())
                    .append("#")
                    .append(goodId)
                    .append("</b> 未指定任何初筛规则</p>");
            hasError = true;
            rules = new ArrayList<>();
        }else rules = ruleService.getBaseMapper().selectBatchIds(filters);


        jedis.set(RedisPrefix.FILTER_DEPOSIT_STATUS + goodId, "running");
        jedis.del(RedisPrefix.FILTER_DEPOSIT_RESULT + goodId);
        jedis.del(RedisPrefix.FILTER_DEPOSIT_REASON + goodId);

        Map<String, String> resultMap = new HashMap<>();
        Map<String, String> reasonMap = new HashMap<>();

        for (Client client : clients) {
            List<Rule> failedRules = new ArrayList<>();
            JSONObject clientInfo = client.getAttribute();
            if (clientInfo == null) {
                hasError = true;
                errorText
                        .append("<p>用户 <b>")
                        .append(client.getUsername())
                        .append("#")
                        .append(client.getId())
                        .append("</b> 信息不存在</p>");
                continue;
            }
            boolean clientRes = true;
            for (Rule rule : rules) {
                switch (judgeRule(clientInfo, rule)) {
                    case -1:
                        clientRes = false;
                        failedRules.add(rule);
                        break;
                    case -2:
                        errorText
                                .append("<p>规则配置错误:<b>")
                                .append(rule.getName())
                                .append("</b> 未指定驱动变量名</p>");
                        hasError = true;
                        break;
                    case -3:
                        errorText
                                .append("<p>规则配置 <b>")
                                .append(rule.getName())
                                .append("</b> 的驱动变量 <b>")
                                .append(rule.getVariable())
                                .append("</b> 在用户 <b>")
                                .append(client.getUsername())
                                .append("#")
                                .append(client.getId())
                                .append("中不存在</b></p>");
                        hasError = true;
                        break;
                }
            }
            if (clientRes) {
                resultMap.put(String.valueOf(client.getId()), "pass");
                reasonMap.put(String.valueOf(client.getId()), "[]");
                //System.out.println(client.getUsername() + "#" + client.getId().toString() + " 审查【通过】");
            } else {
                resultMap.put(String.valueOf(client.getId()), "reject");
                reasonMap.put(String.valueOf(client.getId()), JSONObject.toJSONString(failedRules));
                //System.out.println(client.getUsername() + "#" + client.getId().toString() + " 审查【拒绝】:" + failedRules);
            }
        }
        jedis.hset(RedisPrefix.FILTER_DEPOSIT_RESULT + goodId, resultMap);
        jedis.hset(RedisPrefix.FILTER_DEPOSIT_REASON + goodId, reasonMap);
        jedis.set(RedisPrefix.FILTER_DEPOSIT_STATUS + goodId, "finished");
        jedis.close();
        System.out.println("DEPOSIT_" + goodId.toString() + "初筛已完成");
        if(hasError){
            mailSendService.sendToAdmin("商品 "+good.getName() +" 初筛时发生了错误！","错误报告",errorText.toString());
        }
    }

    private synchronized void controlThread(Boolean toStart) {
        System.out.print("【初筛循环】");
        if (toStart) {
            if (!isRunning) {
                isRunning = true;
                System.out.println("初筛循环_已启动循环");
                preFilterWorkLoop();
            }
        } else {
            System.out.println("初筛循环_已终止循环");
            isRunning = false;
        }
    }

    /**
     * 获取初筛结果
     *
     * @param isLoans  是否贷款
     * @param goodId   商品ID
     * @param clientId 客户ID
     * @return
     */
    @Override
    public Map<String, Object> getFilterState(Boolean isLoans, Integer goodId, Integer clientId) {
        Jedis jedis = getJedis();
        assert jedis != null;
        String ret, reasonStr = "";
        Map<String, Object> retObj = new HashMap<>();
        JSONArray reasonObj;
        if (isLoans) {
            if (!jedis.exists(RedisPrefix.FILTER_LOANS_STATUS + goodId)) {
                ret = "notFound";
            } else if (!Objects.equals(jedis.get(RedisPrefix.FILTER_LOANS_STATUS + goodId), "finished")) {
                ret = "notFinished";
            } else if (!Objects.equals(jedis.hget(RedisPrefix.FILTER_LOANS_RESULT + goodId, String.valueOf(clientId)), "pass")) {
                ret = "rejected";
            } else {
                ret = "passed";
            }
            if (ret.equals("rejected")) {
                reasonStr = jedis.hget(RedisPrefix.FILTER_LOANS_REASON + goodId, String.valueOf(clientId));
                reasonObj = JSONObject.parseArray(reasonStr);
            } else {
                reasonObj = new JSONArray();
            }
        } else {
            if (!jedis.exists(RedisPrefix.FILTER_DEPOSIT_STATUS + goodId)) {
                ret = "notFound";
            } else if (!Objects.equals(jedis.get(RedisPrefix.FILTER_DEPOSIT_STATUS + goodId), "finished")) {
                ret = "notFinished";
            } else if (!Objects.equals(jedis.hget(RedisPrefix.FILTER_DEPOSIT_RESULT + goodId, String.valueOf(clientId)), "pass")) {
                ret = "rejected";
            } else {
                ret = "passed";
            }
            if (ret.equals("rejected")) {
                reasonStr = jedis.hget(RedisPrefix.FILTER_DEPOSIT_REASON + goodId, String.valueOf(clientId));
                reasonObj = JSONObject.parseArray(reasonStr);
            } else {
                reasonObj = new JSONArray();
            }
        }
        retObj.put("state", ret);
        retObj.put("reason", reasonObj);
        JSONObject filterLog = new JSONObject();
        filterLog.put("userId", clientId.toString());
        filterLog.put("goodId", goodId.toString());
        filterLog.put("isLoans", isLoans.toString());
        filterLog.put("result", ret);
        filterLog.put("reason", reasonObj);
        filterLog.put("createTime", new Date());
        jedis.lpush(
                isLoans ? RedisPrefix.FILTER_LOG_LOANS : RedisPrefix.FILTER_LOG_DEPOSIT,
                filterLog.toJSONString()
        );
        jedis.close();
        return retObj;
    }

    /**
     * 获取初筛的失败原因
     *
     * @param isLoans  是否贷款
     * @param goodId   商品ID
     * @param clientId 客户ID
     * @return
     */
    @Override
    public JSONArray getFilterReason(Boolean isLoans, Integer goodId, Integer clientId) {
        Jedis jedis = getJedis();
        assert jedis != null;
        String reasonStr;
        if (isLoans) {
            reasonStr = jedis.hget(RedisPrefix.FILTER_LOANS_REASON + goodId, String.valueOf(clientId));
        } else {
            reasonStr = jedis.hget(RedisPrefix.FILTER_DEPOSIT_REASON + goodId, String.valueOf(clientId));
        }
        jedis.close();
        return JSONObject.parseArray(reasonStr);
    }

    /**
     * 清除某个贷款的初筛数据
     *
     * @param goodId 商品ID
     */
    @Override
    public void clearFilterLoans(Integer goodId) {
        Jedis jedis = getJedis();
        assert jedis != null;
        jedis.del(RedisPrefix.FILTER_LOANS_STATUS + goodId);
        jedis.del(RedisPrefix.FILTER_LOANS_RESULT + goodId);
        jedis.del(RedisPrefix.FILTER_LOANS_REASON + goodId);
        jedis.close();
    }

    /**
     * 清除某个贷款的初筛数据
     *
     * @param goodId
     */
    @Override
    public void clearFilterDeposit(Integer goodId) {
        Jedis jedis = getJedis();
        assert jedis != null;
        jedis.del(RedisPrefix.FILTER_DEPOSIT_STATUS + goodId);
        jedis.del(RedisPrefix.FILTER_DEPOSIT_RESULT + goodId);
        jedis.del(RedisPrefix.FILTER_DEPOSIT_REASON + goodId);
        jedis.close();
    }
    public Boolean hasFiltered(Boolean isLoans, Integer goodId){
        Jedis jedis = getJedis();
        assert jedis != null;
        Boolean res = jedis.exists((isLoans?RedisPrefix.FILTER_LOANS_STATUS:RedisPrefix.FILTER_DEPOSIT_STATUS) + goodId);
        jedis.close();
        return res;
    }
    /**
     * 单条规则初筛（单条）
     *
     * @param clientInfo
     * @param rule
     * @return
     */
    private Integer judgeRule(JSONObject clientInfo, Rule rule) {

        boolean ruleRes;
        boolean control = rule.getControl();
        String var = rule.getVariable();
        if (StringUtil.isBlank(var)) {
            return -2;
        }
        String varVal = clientInfo.getString(var);
        if (StringUtil.isBlank(varVal)) {

            return -3;
        }
        List<String> varSet = rule.getValue();
        String tmpStr1, tmpStr2;
        switch (rule.getType()) {
            case 0://等于
                ruleRes = StringUtil.isNotBlank(tmpStr1 = varSet.get(0))
                        &&
                        tmpStr1.equals(varVal);
                break;
            case 1:
                ruleRes = StringUtil.isNotBlank(tmpStr1 = varSet.get(0))
                        &&
                        Double.parseDouble(tmpStr1) < Double.parseDouble(varVal);
                break;
            case 2:
                ruleRes = StringUtil.isNotBlank(tmpStr1 = varSet.get(0))
                        &&
                        Double.parseDouble(tmpStr1) > Double.parseDouble(varVal);
                break;
            case 3:
                ruleRes = StringUtil.isNotBlank(tmpStr1 = varSet.get(0))
                        &&
                        StringUtil.isNotBlank(tmpStr2 = varSet.get(1))
                        &&
                        Double.parseDouble(tmpStr1) < Double.parseDouble(varVal)
                        &&
                        Double.parseDouble(tmpStr2) > Double.parseDouble(varVal);
                break;
            case 4:
                ruleRes = varSet.contains(varVal);
                break;
            default:
                ruleRes = false;
        }

        return (ruleRes ^ control)?-1:0;
    }
}