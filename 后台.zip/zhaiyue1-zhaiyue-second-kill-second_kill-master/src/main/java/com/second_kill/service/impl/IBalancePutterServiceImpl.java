package com.second_kill.service.impl;

import com.second_kill.config.RedisPrefix;
import com.second_kill.service.IGoodOnSaleService;
import com.second_kill.service.IBalancePutterService;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;

import static com.second_kill.utils.JedisUtil.getJedis;

/*
this class is a part of a SUPER MAGIC !
 */
@Service
@EnableAsync
public class IBalancePutterServiceImpl implements IBalancePutterService {
    @Autowired
    IGoodOnSaleService goodOnSaleService;
    List<JedisEditObj> queue = Collections.synchronizedList(new ArrayList<>());
    boolean isRunning = false;
    @Override
    public void redis_hset(Integer userId, Double changeVal) {
        queue.add(new JedisEditObj(userId,changeVal));
    }

    @Data
    @AllArgsConstructor
    private static class JedisEditObj {
        Integer userId;
        Double changeVal;
    }

    @Async
    @Scheduled(fixedRate = 1000)
    @Override
    public void putVal(){
        if(isRunning)return;
        isRunning=true;
        Jedis jedis = getJedis();
        assert jedis!=null;
        try {
            JedisEditObj tmp;
            while (!queue.isEmpty()) {
                tmp = queue.get(0);
                goodOnSaleService.addBalance(tmp.getUserId(),tmp.getChangeVal(),jedis);
                queue.remove(0);
            }
        }catch (Exception e){e.printStackTrace();}
        isRunning=false;
    }

    @Override
    public double getUncosted(Integer userId){
        AtomicReference<Double> retTmp = new AtomicReference<>(0.0);
        queue.forEach((v)->{
            if(Objects.equals(v.getUserId(), userId)) retTmp.updateAndGet(v1 -> v1 + v.getChangeVal());
        });
        return retTmp.get();
    }
    @Override
    public synchronized Integer preCostBalance(Integer userId, Double changeVal, Jedis jedis){
        Double balanceTmp;
        try{
            balanceTmp = Double.valueOf(jedis.hget(RedisPrefix.USER_DATA + userId, "balance"));
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
        if(balanceTmp+changeVal<0)return -2;
        balanceTmp += getUncosted(userId);
        if(balanceTmp+changeVal<0)return -2;
        queue.add(new JedisEditObj(userId,changeVal));
        return 0;
    }
}
