package com.second_kill.service.impl;

import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.config.RedisPrefix;
import com.second_kill.entity.Client;
import com.second_kill.entity.UserCode;
import com.second_kill.mapper.IClientMapper;
import com.second_kill.mapper.IUserCodeMapper;
import com.second_kill.service.IClientService;
import com.second_kill.service.IPreFilterService;
import com.second_kill.service.ex.SystemException;
import com.second_kill.utils.JedisUtil;
import com.second_kill.utils.Sm4Util;
import com.second_kill.utils.StringUtil;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import redis.clients.jedis.Jedis;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
public class IClientServiceImpl extends ServiceImpl<IClientMapper, Client> implements IClientService {
    @Autowired
    IClientMapper userMapper;

    @Autowired
    IUserCodeMapper userCodeMapper;

    @Autowired
    IPreFilterService preFilterService;

    /**
     * 手机号密码登录
     *
     * @param pOrU     手机号或用户名
     * @param password 密码
     * @return
     */

    @Override
    public Client loginPwd(String pOrU, String password) throws Exception {
        Client realClient = getUserByPOrU(pOrU);
        if (realClient == null) {
            throw new SystemException("用户不存在");
        }
        String Sm4Password = realClient.getPassword(); //数据库中的Sm4密码
        String salt = realClient.getSalt(); //数据库中的salt
        if (!Sm4Util.verifyEcb(salt, Sm4Password, password)) {
            throw new SystemException("密码错误");
        }
        return realClient;
    }

    public Client checkPhone(String phone) {
        QueryWrapper<Client> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("phone", phone);
        return userMapper.selectOne(queryWrapper); //查询数据库中的用户信息
    }


    /**
     * 更新密码、忘记密码、添加密码
     *
     * @param pOrU       手机号或用户名
     * @param verifyCode 手机验证码()
     * @param password   密码
     * @return
     */
    @Override
    public Integer updatePwd(String pOrU, Integer verifyCode, String password) throws Exception {
        Client realClient = getUserByPOrU(pOrU);
        if (realClient == null) {
            throw new SystemException("用户不存在");
        }
        UpdateWrapper<Client> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("phone", realClient.getPhone());
        Client client = new Client();
        String salt = Sm4Util.generateHexString();
        client.setSalt(salt);
        String Sm4Password = Sm4Util.encryptEcb(salt, password);//生成加密后的密码
        client.setPassword(Sm4Password);

        Jedis jedis = JedisUtil.getJedis();
        assert jedis != null;
        Map<String, String> clientInfo = new HashMap<>();
        clientInfo.put("salt", salt);
        clientInfo.put("password", Sm4Password);
        clientInfo.put("phone", realClient.getPhone());
        clientInfo.put("userId", realClient.getId().toString());

        jedis.hset(RedisPrefix.USERNAME_PASSWORD, realClient.getUsername(), JSON.toJSONString(clientInfo));
        jedis.hset(RedisPrefix.PHONE_PASSWORD, realClient.getPhone(), JSON.toJSONString(clientInfo));

        jedis.close();
        return userMapper.update(client, updateWrapper);
    }

    /**
     * 注册
     *
     * @param phone      手机号
     * @param username   用户名
     * @param password   密码
     * @param verifyCode 手机验证码
     */
    @Override
    public void register(String phone, String username, String password, Integer verifyCode) throws Exception {
        if (StringUtil.isBlank(username)) {
            username = "zy_" + phone;
        }

        QueryWrapper<UserCode> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("phone", phone);
        Long count = userCodeMapper.selectCount(queryWrapper);
        if (count > 0) {
            throw new SystemException("手机号被占用");
        }
        QueryWrapper<UserCode> queryWrapper1 = new QueryWrapper<>();
        queryWrapper1.eq("username", username);
        Long count1 = userCodeMapper.selectCount(queryWrapper1);
        if (count1 > 0) {
            throw new SystemException("用户名被占用");
        }
        Client client = new Client();
        String salt = Sm4Util.generateHexString();
        String Sm4Password = null;
        Sm4Password = Sm4Util.encryptEcb(salt, password);
        client.setPassword(Sm4Password);
        client.setUsername(username);
        client.setSalt(salt);
        client.setPhone(phone);
        client.setCreateTime(new Date());
        userMapper.insert(client);

        //初始化用户数据
        Jedis jedis = JedisUtil.getJedis();
        assert jedis != null;
        jedis.hset(RedisPrefix.USER_BALANCE, client.getId().toString(), "0");
        Map<String, String> SaltAndPassword = new HashMap<>();
        SaltAndPassword.put("salt", client.getSalt());
        SaltAndPassword.put("password", client.getPassword());
        Map<String, String> clientInfo = new HashMap<>();
        clientInfo.put("salt", client.getSalt());
        clientInfo.put("password", client.getPassword());
        clientInfo.put("phone", client.getPhone());
        clientInfo.put("userId", client.getId().toString());
        jedis.hset(RedisPrefix.USER_PASSWORD, client.getId().toString(), JSON.toJSONString(SaltAndPassword));
        jedis.hset(RedisPrefix.PHONE_PASSWORD, client.getPhone(), JSON.toJSONString(clientInfo));
        jedis.hset(RedisPrefix.USERNAME_PASSWORD, client.getUsername(), JSON.toJSONString(clientInfo));
        preFilterService.updateAllFilter();
        jedis.close();
    }

    /**
     * 编辑个人信息，不包括手机号、真实姓名
     *
     * @param client 用户信息
     */
    @Override
    public void editInfo(Client client) {
        String username = client.getUsername();
        QueryWrapper<Client> userQueryWrapper = new QueryWrapper<>();
        userQueryWrapper.eq("username", username);
        Client aim = userMapper.selectOne(userQueryWrapper);
        Long count = userMapper.selectCount(userQueryWrapper);
        if (count > 0 && !aim.getId().equals(client.getId())) {
            throw new SystemException("用户名被占用");
        }
        Client updClient = new Client();
        updClient.setUsername(client.getUsername());
        updClient.setAvatar(client.getAvatar());
        UpdateWrapper<Client> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("id", client.getId());
        Client ct = userMapper.selectById(client.getId());
        String oldUsername = ct.getUsername();
        userMapper.update(updClient, updateWrapper);

        //在redis中修改用户名
        if(!username.equals(oldUsername)){
            Jedis jedis = JedisUtil.getJedis();
            assert jedis != null;
            jedis.hset(RedisPrefix.USERNAME_PASSWORD, username, jedis.hget(RedisPrefix.USERNAME_PASSWORD, oldUsername));
            jedis.hdel(RedisPrefix.USERNAME_PASSWORD, oldUsername);
            jedis.close();
        }
    }

    /**
     * 判读输入的是手机号还是用户名
     *
     * @param pOrU 手机号或者用户名
     * @return
     */
    private Client getUserByPOrU(String pOrU) {
        QueryWrapper<Client> queryWrapper = new QueryWrapper<>();
        if (Pattern.matches("^1[3-9]\\d{9}$", pOrU)) {
            queryWrapper.eq("phone", pOrU);
        } else {
            queryWrapper.eq("username", pOrU);
        }
        return userMapper.selectOne(queryWrapper); //查询数据库中的用户信息
    }


}