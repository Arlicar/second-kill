package com.second_kill.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.LoansResult;
import com.second_kill.mapper.ILoansResultMapper;
import com.second_kill.service.ILoansResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ILoansResultServiceImpl extends ServiceImpl<ILoansResultMapper, LoansResult> implements ILoansResultService {

    @Autowired
    ILoansResultMapper loansResultMapper;

    /**
     * 获取存款初筛结果
     *
     * @param goodId
     * @param page
     * @param size
     * @return
     */
    @Override
    public List<LoansResult> loansFilterResult(Integer goodId, Integer page, Integer size) {
        page = page - 1;
        return loansResultMapper.loansFilterResult(goodId, page, size);
    }
}