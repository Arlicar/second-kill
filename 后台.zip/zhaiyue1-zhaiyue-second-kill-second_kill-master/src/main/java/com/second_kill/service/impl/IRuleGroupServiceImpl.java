package com.second_kill.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.RuleGroup;
import com.second_kill.mapper.IRuleGroupMapper;
import com.second_kill.service.IRuleGroupService;
import com.second_kill.service.ex.SystemException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IRuleGroupServiceImpl extends ServiceImpl<IRuleGroupMapper, RuleGroup> implements IRuleGroupService {
    @Autowired
    IRuleGroupMapper ruleGroupMapper;

    /**
     * 删除规则组
     *
     * @param id
     */
    @Override
    public void deleteRuleGroup(Integer id) {
        RuleGroup ruleGroup = ruleGroupMapper.selectById(id);
        if (ruleGroup == null) {
            throw new SystemException("该规则组合不存在");
        } else {
            ruleGroupMapper.deleteById(id);
        }
    }
}
