package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.Client;


/**
 * @author zjy
 * @date 2021-12-29 9:28
 */
public interface IClientService extends IService<Client> {
    /**
     * 通过手机号与密码注册
     *
     * @param phone    手机号
     * @param password 密码
     * @return
     */
    Client loginPwd(String phone, String password) throws Exception;

    /**
     * 检查手机号对应的账号是否存在,是则返回Client对象
     *
     * @param phone
     * @return
     */
    Client checkPhone(String phone);

    /**
     * 更新密码或添加
     *
     * @param phone
     * @param verifyCode
     * @param password
     * @return
     */
    Integer updatePwd(String phone, Integer verifyCode, String password) throws Exception;

    /**
     * 注册
     *
     * @param phone
     * @param username
     * @param password
     * @param verifyCode 手机验证码
     */
    void register(String phone, String username, String password, Integer verifyCode) throws Exception;

    void editInfo(Client client);
}
