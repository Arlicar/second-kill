package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.*;


public interface ILoansGoodService extends IService<LoansGood> {
    PagesBean search(GoodSearch goodSearch);

    PagesBean getLoanListById(OrderFactor orderFactor);

    PagesBean getAllOrder(AllOrderFactor orderFactor);
}
