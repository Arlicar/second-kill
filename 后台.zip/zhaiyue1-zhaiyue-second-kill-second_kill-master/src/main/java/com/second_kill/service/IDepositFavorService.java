package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.DepositFavor;

import java.util.List;

public interface IDepositFavorService extends IService<DepositFavor> {
    List<DepositFavor> getByUGId(Integer goodId, Integer userId);
}
