package com.second_kill.service;

import com.alibaba.fastjson.JSONArray;
import com.second_kill.entity.Client;
import com.second_kill.entity.DepositGood;
import com.second_kill.entity.LoansGood;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface IPreFilterService {
    void updateFilterLoans(LoansGood good, List<Client> users);

    void updateFilterDeposit(DepositGood good, List<Client> users);

    void updateFilterLoans(LoansGood good, Client user);

    void updateFilterDeposit(DepositGood good, Client user);

    void updateFilterLoans(LoansGood good);

    void updateFilterDeposit(DepositGood good);
    /**
     * 更新所有初筛信息，当用户信息被导入时触发
     */
    void updateAllFilter();
    void updateAllFilter(Client user);
    /**
     * 获取初筛状态。返回：notFinished,passed,rejected中的一个字符串
     *
     * @param isLoans  是否贷款
     * @param goodId   商品ID
     * @param clientId 客户ID
     * @return 见描述
     */
    Map<String, Object> getFilterState(Boolean isLoans, Integer goodId, Integer clientId);

    /**
     * 获取初筛未通过原因。返回LIST。
     *
     * @param isLoans  是否贷款
     * @param goodId   商品ID
     * @param clientId 客户ID
     * @return 若通过返回空的对象
     */
    JSONArray getFilterReason(Boolean isLoans, Integer goodId, Integer clientId);

    /**
     * 清除某个贷款的初筛数据
     *
     * @param goodId
     */
    void clearFilterLoans(Integer goodId);

    /**
     * 清除某个贷款的初筛数据
     *
     * @param goodId
     */
    void clearFilterDeposit(Integer goodId);
    Boolean hasFiltered(Boolean isLoans, Integer goodId);
}
