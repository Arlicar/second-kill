package com.second_kill.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.second_kill.entity.Rule;

public interface IRuleService extends IService<Rule> {
    void addRule(Rule rule);

    void deleteRule(Integer id);

    void modifyRule(Rule rule);
}
