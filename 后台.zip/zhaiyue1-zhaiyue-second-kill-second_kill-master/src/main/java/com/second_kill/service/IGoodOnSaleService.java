package com.second_kill.service;


import com.second_kill.entity.DepositGood;
import com.second_kill.entity.LoansGood;
import com.second_kill.entity.OrderInfo;
import redis.clients.jedis.Jedis;

public interface IGoodOnSaleService {
    /**
     * 初始化商品类型
     *
     * @param good 商品
     */
    void initGoodInfo(LoansGood good);

    void initGoodInfo(DepositGood good);

    /**
     * 扣库存并创建订单，创建订单阶段<br>
     * 该方法将先检查用户余量和商品余量，若可以购买则创建订单ID并减少两个余量<br>
     * 该方法已使用CAS<br>
     *
     * @param order orderInfo对象
     * @return -1:表更改失败,-2:商品不足或超过限购，部分成功,-3:商品不足，-4:超过限购，失败，0：成功
     */
    Integer createOrder(OrderInfo order, Jedis jedis);

    Boolean isGoodInSale(Boolean isLoans, Integer goodId, Jedis jedis);

    Integer payBackOrder(OrderInfo order, Integer userId);

    Integer addBalance(Integer userId, Double change, Jedis jedis);

    /**
     * 回滚创建的订单，用于过期商品加回库存
     *
     * @param order orderInfo对象
     * @return -1:表更改失败,-2:商品不足或超过限购，部分成功,-3:商品不足，-4:超过限购，失败，0：成功
     */
    Boolean rollBackOrder(OrderInfo order);

    /**
     * 生成队列ID<br>
     * QueueID用于前端轮询获取Status和OrderId<br>
     * QueueID为用户ID和时间对15分钟取模的拼接串
     *
     * @param userId 商品ID
     * @return String 队列ID
     */
    String getQueueId(Integer userId);

    Double getCompanyAccount();

    void setCompanyAccount(double companyAccount, Boolean relative);
}
