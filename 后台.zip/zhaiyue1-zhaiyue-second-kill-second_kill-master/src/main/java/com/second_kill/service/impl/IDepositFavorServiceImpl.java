package com.second_kill.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.second_kill.entity.DepositFavor;
import com.second_kill.mapper.IDepositFavorMapper;
import com.second_kill.service.IDepositFavorService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IDepositFavorServiceImpl extends ServiceImpl<IDepositFavorMapper, DepositFavor> implements IDepositFavorService {

    @Override
    public List<DepositFavor> getByUGId(Integer goodId, Integer userId) {
        QueryWrapper<DepositFavor> qw = new QueryWrapper<>();
        qw.eq("goodId", goodId);
        qw.eq("userId", userId);
        return this.getBaseMapper().selectList(qw);
    }
}
