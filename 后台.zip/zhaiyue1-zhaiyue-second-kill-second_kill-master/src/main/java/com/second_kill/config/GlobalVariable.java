package com.second_kill.config;

import lombok.Data;
import org.springframework.stereotype.Component;

import javax.annotation.security.DenyAll;

@Component
@Data
public class GlobalVariable {
    private Boolean variable = false;
}
