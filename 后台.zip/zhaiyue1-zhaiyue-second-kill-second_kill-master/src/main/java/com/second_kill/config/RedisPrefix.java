package com.second_kill.config;


public class RedisPrefix {
    public static String TOTAL_USER = "total_user";
    public static String VISITS = "visits";
    public static String NEW_USER = "new_user";
    public static String AMOUNT_LOANS = "amount_loans";
    public static String AMOUNT_DEPOSIT = "amount_deposit";
    public static String ORDER_NUMBER = "order_number";
    public static String ORDER_NUMBER_DEPOSIT = "order_number_deposit";
    public static String ORDER_NUMBER_LOANS = "order_number_loans";
    public static String CUSTOMER_ONCE_CONSUMED = "customer_once_consumed";
    public static String CUSTOMER_REGULAR_CONSUMED = "customer_regular_consumed";

    public static String SALE_NUMBER_LOANS = "sale_number_loans_";
    public static String SALE_PRICE_LOANS = "sale_price_loans_";
    public static String SALE_NUMBER_DEPOSIT = "sale_number_deposit_";
    public static String SALE_PRICE_DEPOSIT = "sale_price_deposit_";

    /**
     * 线程，总线程，用于更新所有初筛(贷款)
     */
    public static String LOANS = "loans";
    /**
     * 线程，总线程，用于更新所有初筛(存款)
     */
    public static String DEPOSIT = "deposit";

    /**
     * 贷款的初筛运行状态（String，为running，finished或不存在）
     */
    public static String FILTER_LOANS_STATUS = "filter_loans_status_";
    /**
     * 贷款的初筛结果（Hash，key为USERID，VALUE为passed，rejected或不存在)
     */
    public static String FILTER_LOANS_RESULT = "filter_loans_result_";
    /**
     * 贷款的初筛不通过的原因（Hash，key为USERID，VALUE为空串，未通过的原因列表（json）或不存在)
     */
    public static String FILTER_LOANS_REASON = "filter_loans_reason_";
    /**
     * 存款的初筛运行状态（String，为running，finished或不存在）
     */
    public static String FILTER_DEPOSIT_STATUS = "filter_deposit_status_";
    /**
     * 存款的初筛结果（Hash，key为USERID，VALUE为passed，rejected或不存在)
     */
    public static String FILTER_DEPOSIT_RESULT = "filter_deposit_result_";
    /**
     * 存款的初筛不通过的原因（Hash，key为USERID，VALUE为空串，未通过的原因列表（json）或不存在)
     */
    public static String FILTER_DEPOSIT_REASON = "filter_deposit_reason_";

    /**
     * 缓存的存款商品信息（hash,包含price,restrict,remain,total)
     */
    public static String GOOD_DEPOSIT_INFO = "good_deposit_info_";
    /**
     * 缓存的存款用户信息（hash,key为用户ID，value为剩余购买量或不存在)
     */
    public static String GOOD_DEPOSIT_USER = "good_deposit_user_";
    /**
     * 缓存的贷款商品信息（hash,包含price,restrict,remain,total)
     */
    public static String GOOD_LOANS_INFO = "good_loans_info_";
    /**
     * 缓存的贷款用户信息（hash,key为用户ID，value为剩余购买量或不存在)
     */
    public static String GOOD_LOANS_USER = "good_loans_user_";

    /**
     * 已创建的贷款订单
     */
    public static String ORDER_LOANS = "order_loans_";
    /**
     * 已创建的存款订单
     */
    public static String ORDER_DEPOSIT = "order_deposit_";
    /**
     * 已申请退款的贷款订单
     */
    public static String ORDER_LOANS_REFUND = "order_loans_refund";
    /**
     * 已申请退款的存款订单
     */
    public static String ORDER_DEPOSIT_REFUND = "order_deposit_refund";

    /**
     * 最大贷款订单ID
     */
    public static String ORDER_ID_LOANS = "loans_order_id";
    /**
     * 最大存款订单ID
     */
    public static String ORDER_ID_DEPOSIT = "deposit_order_id";

    public static String USER_BALANCE = "user_balance";
    /**
     * 后跟userId存hash，表示用户的所有数据（包括限购，余额）
     */
    public static String USER_DATA = "user_data_";
    public static String USER_PASSWORD = "user_password";

    /**
     * 贷款初筛LOG
     */
    public static String FILTER_LOG_LOANS = "filter_log_loans";
    /**
     * 存款初筛LOG
     */
    public static String FILTER_LOG_DEPOSIT = "filter_log_deposit";

    /**
     * 手机登录
     */
    public static String PHONE_PASSWORD = "phone_password";

    /**
     * 用户名登录
     */
    public static String USERNAME_PASSWORD = "username_password";
}
